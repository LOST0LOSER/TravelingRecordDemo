public class ResultJSON {
    // 需要转译
    private int current_position;
    private String current_time;
    private int costs;
    private int left_money;
    public Plan[] plan = new Plan[3];

    public ResultJSON() {
        current_position = 0;
        current_time = null;
        costs = 0;
        left_money = 0;
    }

    public ResultJSON(int cur_pos, String cur_time, int cos, int $) {
        current_position = cur_pos;
        current_time = cur_time;
        costs = cos;
        left_money = $;
    }

    public void set_current_position(int var) {
        current_position = var;
    }

    public void set_current_time(String var) {
        current_time = var;
    }

    public void set_costs(int var) {
        costs = var;
    }

    public void set_left_money(int var) {
        left_money = var;
    }
    
    public void set_plan(int index,String start, String end, String[] ve, int[] cit , String[] time){
        this.plan[index] = new Plan(start, end, ve, cit ,time);
    }
}

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.Integer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

public class travelServlet extends HttpServlet{
	
	private static final long serialVersionUID = 1L;
	private static String input_json;
	Gson gson = new Gson();
	GetJSON data = new GetJSON();
	ResultJSON result_data = new ResultJSON();
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException {
		
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException,IOException {
		try{
			System.out.println("正在处理Post请求");
			//定义编码为utf-8,数据类型为json
			request.setCharacterEncoding("utf-8");
			response.setCharacterEncoding("utf-8");
			response.setContentType("application/json;charset=utf-8");
			/**
			 * 接收json
			 */
			BufferedReader reader = request.getReader();
			input_json = reader.readLine();
			reader.close();
			System.out.println("已接受数据");
			//中文转码,以utf-8为标准
			//byte[] input_json_bytes=  input_json.getBytes("ISO-8859-1");//字节流ISO-8859-1
			//input_json = new String(input_json_bytes,"utf-8");//转换为utf-8标准


			//把json字符串转为java对象
			data = gson.fromJson(input_json, GetJSON.class);
			data.testdata();
			//System.out.println(data.start_time);


			//业务逻辑代码区
			//System.out.println(data.get_start_position());

			int cnum = 10;
            Edge timeList[] = new Edge[5000];
            int i = test.readFile(timeList);
            bfs_dp picture = new bfs_dp(i, cnum, timeList);
            picture.method(data.get_start_time(), data.get_start_position(),
                    data.get_destination(), data.get_limited_time());
			System.out.println("test ok");
            picture.printSolution();
			result_data = new ResultJSON(picture.get_start_position(),picture.get_start_time(),
					0,0);
			//System.out.println(picture.get_start_time());
			//System.out.println(picture.get_end_time());
			/*
			for(int index=0;index<3;index++){
				System.out.println(picture.get_vehicles()[index]);
			}*/
			//方案3 bfs
			int[] cit = picture.get_cities();
			String[] vehicle = picture.get_vehicles();
			String[] time =picture.get_cities_time();
			result_data.set_plan(0,picture.get_start_time(),picture.get_end_time(),vehicle
					,cit,time);



            data=null;
			//虚假返回数据，用于测试
			//建立结果类标准

			cit = new int[]{4,5,6,1,4,3,2,1};
			vehicle = new String[]{"火车","火车","火车","火车","火车","火车","火车","火车"};
			
			result_data.set_plan(2,"1:00","10:00",vehicle,cit,null);
			result_data.set_plan(1,"2:00","11:00",vehicle,cit,null);
			//result_data.set_plan(2,"3:00","12:00",vehicle,cit,null);

			String result_json = gson.toJson(result_data);
			result_data=null;
			/**
			 * 返回json
			**/
			System.out.println(result_json);
			PrintWriter out = response.getWriter();//字符串输出对象
			//ServletOutputStream out = response.getOutputStream();//输出流
			out.write(result_json);//返回字符串给前端			
			out.flush();
			out.close();
			System.out.println("处理Post完毕,已返回数据");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

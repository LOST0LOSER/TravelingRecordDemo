public class Plan {
    private String start_time;
    private String end_time;
    private String[] vehicle;
    private int[] cities;
    private String[] cities_times;

    public Plan() {
        start_time = null;
        end_time = null;
        vehicle = null;
        cities = null;
        cities_times = null;
    }

    public Plan(String start, String end, String[] ve, int[] cit,String[] time) {
        start_time = start;
        end_time = end;
        vehicle = ve;
        cities = cit;
        cities_times = time;
    }

    // 写入数据
    public void set_all(String first, String second, String[] third, int[] forth ,String[] fifth) {
        start_time = first;
        start_time = second;
        vehicle = third;
        cities = forth;
        cities_times = fifth;
    }
}